namespace ProgramDziedziczeniaAuto
{
	public interface ILiczbaOsi
	{
		void parametrLiczbaOsi(int liczbaOsi);
	}
}