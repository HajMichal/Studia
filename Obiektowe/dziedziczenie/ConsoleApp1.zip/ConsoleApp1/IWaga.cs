namespace ProgramDziedziczeniaAuto
{
	public interface IWaga
	{
		void parametrWaga(int parametrWaga);
	}
}