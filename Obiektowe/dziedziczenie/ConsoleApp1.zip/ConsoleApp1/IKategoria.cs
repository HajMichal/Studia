namespace ProgramDziedziczeniaAuto
{
	public interface IKategoria
	{
		void kategoriaPojazdu(string? kategoriaPojazdu);
	}
}