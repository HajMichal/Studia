namespace ProgramDziedziczeniaAuto
{
	public interface IKolor
	{
		void parametrKolor(string? kolor);
	}
}