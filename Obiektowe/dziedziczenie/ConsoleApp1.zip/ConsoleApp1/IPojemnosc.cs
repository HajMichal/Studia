namespace ProgramDziedziczeniaAuto
{
	public interface IPojemnosc
	{
		void parametrPojemnosc(int pojemnoscSilnika);
	}
}