namespace Hermetyzacja
{
	public enum TypUsterzenia
	{
		górnopłat,
		centropłat,
		dolnopłat
	}
}